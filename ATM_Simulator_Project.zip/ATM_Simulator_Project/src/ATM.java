import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ATM {
    private static final String DATA_FILE = "D:/ATM_Simulator_Project/data/users.dat";
    private static List<Card> users = new ArrayList<>();

    public static void main(String[] args) {
        loadUsers();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== ATM SIMULATOR =====");
            System.out.println("1. New User Registration");
            System.out.println("2. Existing User Login");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    registerNewUser(scanner);
                    break;
                case 2:
                    loginUser(scanner);
                    break;
                case 3:
                    saveUsers();
                    System.out.println("Thank you for using our ATM!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void registerNewUser(Scanner scanner) {
        System.out.println("\n=== NEW USER REGISTRATION ===");

        // Account Details
        System.out.print("Enter Account Holder Name: ");
        String name = scanner.nextLine();

        String accountNumber;
        while (true) {
            System.out.print("Enter Account Number (10 digits): ");
            accountNumber = scanner.nextLine();
            if (accountNumber.matches("\\d{10}")) break;
            System.out.println("Invalid account number format!");
        }

        // Card Details
        String cardNumber;
        while (true) {
            System.out.print("Enter Card Number (XXXX-XXXX-XXXX-XXXX): ");
            cardNumber = scanner.nextLine();
            if (cardNumber.matches("\\d{4}-\\d{4}-\\d{4}-\\d{4}")) break;
            System.out.println("Invalid card number format!");
        }

        // PIN Management
        int pin;
        while (true) {
            System.out.print("Create 4-digit PIN: ");
            pin = scanner.nextInt();
            if (String.valueOf(pin).length() == 4 && isPinUnique(pin)) break;
            System.out.println("Invalid PIN or PIN already exists!");
        }

        // Initial Deposit
        double balance;
        while (true) {
            System.out.print("Initial deposit amount: ");
            balance = scanner.nextDouble();
            if (balance >= 500) break;
            System.out.println("Minimum initial deposit is 500!");
        }

        // Create new user
        Card newUser = new Card(accountNumber, name, cardNumber, pin, balance);
        users.add(newUser);
        saveUsers();
        System.out.println("Registration successful! You can now login.");
    }

    private static void loginUser(Scanner scanner) {
        System.out.println("\n=== EXISTING USER LOGIN ===");

        System.out.print("Enter Card Number: ");
        String cardNumber = scanner.nextLine();

        System.out.print("Enter PIN: ");
        int pin = scanner.nextInt();

        Card user = validateUser(cardNumber, pin);
        if (user != null) {
            showAtmMenu(user, scanner);
        } else {
            System.out.println("Invalid credentials!");
        }
    }

    private static void showAtmMenu(Card user, Scanner scanner) {
        while (true) {
            System.out.println("\n=== ATM MENU ===");
            System.out.println("1. Check Balance");
            System.out.println("2. Cash Withdrawal");
            System.out.println("3. Cash Deposit");
            System.out.println("4. Change PIN");
            System.out.println("5. Fund Transfer");
            System.out.println("6. Account Details");
            System.out.println("7. Generate New PIN");
            System.out.println("8. Activate Net Banking");
            System.out.println("9. View Transaction History");
            System.out.println("10. Logout");
            System.out.print("Enter choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Current Balance: " + user.getBalance());
                    break;

                case 2:
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawAmount = scanner.nextDouble();
                    user.withdraw(withdrawAmount);
                    break;

                case 3:
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = scanner.nextDouble();
                    user.deposit(depositAmount);
                    break;

                case 4:
                    changePin(user, scanner);
                    break;

                case 5:
                    fundTransfer(user, scanner);
                    break;

                case 6:
                    displayAccountDetails(user);
                    break;

                case 7:
                    generateNewPin(user, scanner);
                    break;

                case 8:
                    activateNetBanking(user);
                    break;

                case 9:
                    viewTransactionHistory(user);
                    break;

                case 10:
                    saveUsers();
                    System.out.println("Logged out successfully!");
                    return;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    private static void viewTransactionHistory(Card user) {
        System.out.println("\n=== TRANSACTION HISTORY ===");
        List<Transaction> transactions = user.getTransactions();
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            for (Transaction transaction : transactions) {
                System.out.println(transaction);
            }
        }
    }

    // Helper methods
    private static Card validateUser(String cardNumber, int pin) {
        for (Card user : users) {
            if (user.getCardNumber().equals(cardNumber) && user.verifyPin(pin)) {
                return user;
            }
        }
        return null;
    }

    private static boolean isPinUnique(int pin) {
        for (Card user : users) {
            if (user.verifyPin(pin)) return false;
        }
        return true;
    }

    private static void fundTransfer(Card sender, Scanner scanner) {
        System.out.print("Enter recipient's account number: ");
        String recipientAccount = scanner.next();

        System.out.print("Enter transfer amount: ");
        double amount = scanner.nextDouble();

        Card recipient = findUserByAccount(recipientAccount);
        if (recipient != null) {
            if (sender.getBalance() >= amount) {
                sender.transfer(amount, recipientAccount);
                recipient.deposit(amount);
                System.out.println("Transfer successful!");
            } else {
                System.out.println("Insufficient balance!");
            }
        } else {
            System.out.println("Recipient account not found!");
        }
    }

    private static Card findUserByAccount(String accountNumber) {
        for (Card user : users) {
            if (user.getAccountNumber().equals(accountNumber)) {
                return user;
            }
        }
        return null;
    }

    private static void changePin(Card user, Scanner scanner) {
        System.out.print("Enter current PIN: ");
        int oldPin = scanner.nextInt();

        if (user.verifyPin(oldPin)) {
            int newPin;
            while (true) {
                System.out.print("Enter new 4-digit PIN: ");
                newPin = scanner.nextInt();
                if (String.valueOf(newPin).length() == 4 && isPinUnique(newPin)) break;
                System.out.println("Invalid PIN or PIN already exists!");
            }

            user.changePin(oldPin, newPin);
            System.out.println("PIN changed successfully!");
            System.out.print("Please re-enter new PIN to confirm: ");
            int confirmPin = scanner.nextInt();

            if (user.verifyPin(confirmPin)) {
                System.out.println("PIN verification successful!");
            } else {
                System.out.println("PIN mismatch! Please login again.");
                saveUsers();
                return;
            }
        } else {
            System.out.println("Incorrect current PIN!");
        }
    }

    private static void generateNewPin(Card user, Scanner scanner) {
        System.out.println("Generating new PIN...");
        user.generateNewPin();
        System.out.println("New PIN: " + user.getPin());
        System.out.println("Please change this PIN immediately!");
    }

    private static void activateNetBanking(Card user) {
        if (!user.isNetBankingActivated()) {
            user.activateNetBanking();
            System.out.println("Net banking activated successfully!");
        } else {
            System.out.println("Net banking is already activated.");
        }
    }

    private static void displayAccountDetails(Card user) {
        System.out.println("\n=== ACCOUNT DETAILS ===");
        System.out.println("Account Holder: " + user.getAccountHolderName());
        System.out.println("Account Number: " + user.getAccountNumber());
        System.out.println("Card Number: " + user.getCardNumber());
        System.out.println("Net Banking Status: " +
                (user.isNetBankingActivated() ? "Activated" : "Inactive"));
    }

    // Data persistence methods
    private static void saveUsers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(users);
        } catch (IOException e) {
            System.out.println("Error saving user data: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadUsers() {
        File file = new File(DATA_FILE);
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                users = (List<Card>) ois.readObject();
            } catch (IOException | ClassNotFoundException e) {
                System.out.println("Error loading user data: " + e.getMessage());
            }
        }
    }
}