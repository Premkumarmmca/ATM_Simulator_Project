import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Card implements Serializable {
    // Add a fixed serialVersionUID to ensure compatibility
    private static final long serialVersionUID = 1L;

    private String accountNumber;
    private String accountHolderName;
    private String cardNumber;
    private int pin;
    private double balance;
    private boolean netBankingActivated;
    private List<Transaction> transactions;

    public Card(String accountNumber, String accountHolderName, String cardNumber, int pin, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.cardNumber = cardNumber;
        this.pin = pin;
        this.balance = balance;
        this.netBankingActivated = false;
        this.transactions = new ArrayList<>();
    }

    // Getters
    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public int getPin() {
        return pin;
    }

    public double getBalance() {
        return balance;
    }

    public boolean isNetBankingActivated() {
        return netBankingActivated;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    // PIN Verification
    public boolean verifyPin(int enteredPin) {
        return pin == enteredPin;
    }

    // Transactions
    public void deposit(double amount) {
        balance += amount;
        transactions.add(new Transaction("DEPOSIT", amount));
        System.out.println("Deposit successful. New balance: " + balance);
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            transactions.add(new Transaction("WITHDRAWAL", amount));
            System.out.println("Withdrawal successful. Remaining balance: " + balance);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    public void transfer(double amount, String recipientAccount) {
        if (amount <= balance) {
            balance -= amount;
            transactions.add(new Transaction("TRANSFER to " + recipientAccount, amount));
            System.out.println("Transfer successful. Remaining balance: " + balance);
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    // PIN Management
    public void generateNewPin() {
        pin = 1000 + (int) (Math.random() * 9000); // Generates a 4-digit PIN
        System.out.println("New PIN generated: " + pin);
    }

    public void changePin(int oldPin, int newPin) {
        if (verifyPin(oldPin)) {
            pin = newPin;
            System.out.println("PIN changed successfully.");
        } else {
            System.out.println("Invalid old PIN.");
        }
    }

    // Net Banking
    public void activateNetBanking() {
        netBankingActivated = true;
        System.out.println("Net banking activated successfully.");
    }
}